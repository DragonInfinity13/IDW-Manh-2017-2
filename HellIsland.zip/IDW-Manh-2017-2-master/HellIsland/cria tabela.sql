CREATE TABLE contatos (
	nome varchar(100),
	idade int,
	email varchar(100),
	telefone varchar(30)
);