# IDW-Manh-2017-2
Site basico, com tela de Home, Sobre, Imagens, Demo, Contatos.
Na aba de contato tem os campos para cadastrar e testar o código PHP com a conexão com banco de dados
